package com.example.explore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
